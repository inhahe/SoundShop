#pragma once
#include "Common.h"
#include "audio/Events.h"
#include "audio/Schedulers.h"
#include "audio/ParameterChangeListener.h"

// Queues used to communicate from realtime/audio threads to UI/command thread.
extern LockFreeParameterQueue parameterQueue;
extern LockFreeMidiQueue<MidiNoteEvent> midiNoteQueue;
extern LockFreeMidiQueue<MidiCCEvent> midiCCQueue;
extern LockFreeMidiQueue<MidiNoteEvent> virtualKeyboardNoteQueue;
extern LockFreeMidiQueue<MidiCCEvent> virtualKeyboardCCQueue;

extern ParameterChangeListener paramListener;
