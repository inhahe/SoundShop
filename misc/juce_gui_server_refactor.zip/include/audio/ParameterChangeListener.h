#pragma once
#include "Common.h"
#include "audio/Events.h"
#include "audio/Schedulers.h"

// Forward decls
class CompletePluginHost;

// Declared in Queues.cpp
extern LockFreeParameterQueue parameterQueue;

class ParameterChangeListener : public juce::AudioProcessorListener
{
public:
  void audioProcessorParameterChanged(juce::AudioProcessor* processor,
                                      int parameterIndex,
                                      float newValue) override;
};
