#include "CompletePluginHost.h"
#include "gui/VirtualKeyboardListener.h"
#include "audio/ParameterChangeListener.h"
#include "audio/Queues.h"

void VirtualKeyboardListener::routeToHost(const juce::MidiMessage& message)
{
  if (hostApp)
  {
    hostApp->handleVirtualKeyboardMessage(message);
  }
}

void audioProcessorParameterChanged(juce::AudioProcessor* processor, int paramIndex, float value)
{
  if (!suppressNotifications)
  {
    ParameterChangeEvent event{app->findkey(processor), paramIndex, value, app->scheduler.getTimeSample()};
    parameterQueue.push(event);  // Lock-free, real-time safe
  }
}

void ParameterChangeListener::audioProcessorParameterChanged(juce::AudioProcessor* processor,
                                                            int paramIndex,
                                                            float value)
{
  if (suppressNotifications || !app) return;

  const int key = app->findkey(processor);
  if (key == -1) return;

  // Timeline sample "now" (must be maintained by your audio callback)
  const int64_t atSample = app->paramScheduler.getTimelineSample();
  // or: const int64_t atSample = ::currentSamplePosition;

  ParameterChangeEvent event { key, paramIndex, value, atSample };

  // If you want lock-free:
  // parameterQueue.push(event);

  // If you want "queue then send on notification thread":
  app->queueParameterNotification(event);
}

// Entry point
#ifdef _WIN32
// Use extern "C" to ensure proper linkage

bool isAllWhitespace(const std::string& str) 
{
  return str.empty() || str.find_first_not_of(" \t\n\r\f\v") == std::string::npos;
}

extern "C" int WINAPI 