#include "CompletePluginHost.h"

extern "C" int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
  try {
    if (!isAllWhitespace(lpCmdLine))
    {
      pipeName = lpCmdLine;
    }    
    // Allocate a console window for this GUI application
    AllocConsole();

    // Redirect stdout, stdin, stderr to console
    FILE* p//cout;
    freopen_s(&p//cout, "CONOUT$", "w", stdout);
    freopen_s(&p//cout, "CONOUT$", "w", stderr);
    freopen_s(&p//cout, "CONIN$", "r", stdin);

    freopen_s(&p//cout, "debug_log.txt", "w", stdout);
    freopen_s(&p//cout, "CONOUT$", "w", stderr);


    std:://cout.clear();
    std::cerr.clear();
    std::cin.clear();
 
  // Suppress unused parameter warnings
    (void)hInstance;
    (void)hPrevInstance;
    (void)nCmdShow;
    
#ifdef _WIN64
    //cout << "compiled as 64-bit, so will only detect 64-bit plugins" << std::endl; //todo: notify of plugins found that are the wrong number of bits
#else
    //cout << "compiled as 32-bit, so will only detect 32-bit plugins" << std::endl;
#endif
    //cout << "formats supported:" << endl;
    juce::AudioFormatManager formatManager;
    for (auto* format : formatManager) 
    {  
      std:://cout << format->getFormatName().toStdString() << std::endl;
    }
    //cout << "using pipe: " << pipeName << endl;
    juce::initialiseJuce_GUI();
    app = new CompletePluginHost();
    app->testFunction();
    app->waitForConnection();
    app->initialise(juce::String(lpCmdLine));
    juce::MessageManager::getInstance()->runDispatchLoop();
    app->shutdown();
    juce::shutdownJuce_GUI();
    //cout << endl << "press enter to close..." << endl;
    cin.get();
  } 
  catch (const exception& e) 
  {
    //cout << "exception: " << e.what() << std::endl;
    //cout << endl << "press enter to close..." << endl;
    cin.get();
  }
  return 0;
}
#else
// For Mac/Linux, use standard main
int main(int argc, char* argv[])
{
    juce::initialiseJuce_GUI();
    
    juce::String commandLine;
    if (argc > 1)
    {
        for (int i = 1; i < argc; ++i)
        {
            if (i > 1) commandLine << " ";
            commandLine << argv[i];
        }
    }
    
    CompletePluginHost app;
    app->initialise(commandLine);
    
    juce::MessageManager::getInstance()->runDispatchLoop();
    
    app->shutdown();
    juce::shutdownJuce_GUI();
    
    return 0;
}
#endif

