#include "Common.h"

int sampleRate = 44100;
int blockSize = 64;
bool suppressNotifications = false;
string pipeName = "juceclientserver";
int updateRate = 50;

CompletePluginHost* app = nullptr;
int64_t currentSamplePosition = 0;
