#include "audio/Queues.h"

LockFreeParameterQueue parameterQueue;
LockFreeMidiQueue<MidiNoteEvent> midiNoteQueue;
LockFreeMidiQueue<MidiCCEvent> midiCCQueue;
LockFreeMidiQueue<MidiNoteEvent> virtualKeyboardNoteQueue;
LockFreeMidiQueue<MidiCCEvent> virtualKeyboardCCQueue;

ParameterChangeListener paramListener;
