# juce_gui_server refactor (multi-file)

This is a mechanical split of `juce_gui_server.cpp` into maintainable `.h/.cpp` modules.

## Files to add to your build
Add **all** `.cpp` files under `src/` to your project, and add `include/` to your header search path.

- src/Globals.cpp
- src/CompletePluginHost.cpp
- src/audio/Queues.cpp
- src/audio/RecordingAudioCallback.cpp
- src/gui/Listeners.cpp
- src/main.cpp

## Notes
- Most class method bodies remain inline as in the original file (for minimal behavior change).
- GUI helper classes (`RoutingButton`, `EditorWithButtonsComponent`, `VirtualKeyboardWindow`) were moved out of `CompletePluginHost` into `include/gui/`.
- Global state was centralized: config values are declared `extern` in `include/Common.h` and defined in `src/Globals.cpp`.
