#pragma once
#include "Common.h"
#include "ServerState.h"
class PluginHostService;

// IPC service boundary (named pipes / sockets / command loop).
// Current implementation still lives inside PluginHostService; this is the seam.
class IpcService
{
public:
    IpcService(ServerState& state, PluginHostService& host);
    void start();
    void stop();
private:
    ServerState& state_;
    PluginHostService& host_;
};
