#pragma once
#include "Common.h"
#include "ServerState.h"
class PluginHostService;

// UI service boundary (virtual keyboard window / editor windows / routing buttons).
class UiService
{
public:
    UiService(ServerState& state, PluginHostService& host);
    void showVirtualKeyboard();
    void hideVirtualKeyboard();
private:
    ServerState& state_;
    PluginHostService& host_;
};
