#pragma once
#include "Common.h"
#include "ServerState.h"
#include "audio/RecordingAudioCallback.h"
class PluginHostService;

// Audio service boundary (device manager + callback + recording/rendering).
// Current implementation is split between PluginHostService and RecordingAudioCallback.
class AudioService
{
public:
    AudioService(ServerState& state, PluginHostService& host);
    void start();
    void stop();
    RecordingAudioCallback& callback() { return callback_; }
private:
    ServerState& state_;
    PluginHostService& host_;
    RecordingAudioCallback callback_;
};
