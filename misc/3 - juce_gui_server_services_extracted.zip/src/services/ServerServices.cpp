#include "services/ServerServices.h"

ServerServices::ServerServices(ServerState stateInit)
    : state_(std::move(stateInit))
    , host_(state_)
{
}

int ServerServices::run(int argc, char** argv)
{
    // Today: host_ still owns/starts most subsystems (audio, IPC, UI).
    // Next step (planned): split host_ into IpcService/AudioService/UiService/GraphService
    // and keep host_ as a pure "graph + command handlers" object.
    //
    // For now, preserve behavior by delegating to existing entrypoint pattern.

#if JUCE_WINDOWS
    juce::ignoreUnused(argc, argv);
#endif

    // If your current main.cpp already constructs a JUCEApplication and returns,
    // keep that logic in main.cpp. This class is primarily a dependency container.
    return 0;
}
