#include "services/UiService.h"
#include "host/PluginHostService.h"

UiService::UiService(ServerState& state, PluginHostService& host)
    : state_(state), host_(host) {}

void UiService::showVirtualKeyboard()
{
    // TODO: route to host/UI classes
    // host_.showVirtualKeyboard();
}

void UiService::hideVirtualKeyboard()
{
    // host_.hideVirtualKeyboard();
}
