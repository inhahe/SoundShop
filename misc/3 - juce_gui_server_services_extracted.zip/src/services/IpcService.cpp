#include "services/IpcService.h"
#include "host/PluginHostService.h"

IpcService::IpcService(ServerState& state, PluginHostService& host)
    : state_(state), host_(host) {}

void IpcService::start()
{
    // TODO: move pipe creation + command/notification threads out of PluginHostService
    // host_.startIpc();  // (future)
}

void IpcService::stop()
{
    // TODO: host_.stopIpc(); (future)
}
