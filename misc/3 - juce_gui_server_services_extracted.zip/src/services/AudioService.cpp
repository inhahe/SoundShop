#include "services/AudioService.h"
#include "host/PluginHostService.h"

AudioService::AudioService(ServerState& state, PluginHostService& host)
    : state_(state)
    , host_(host)
    , callback_(host_, state_)
{
}

void AudioService::start()
{
    // TODO: move device manager init/start here from PluginHostService
}

void AudioService::stop()
{
    // TODO
}
