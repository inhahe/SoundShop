#include "services/AudioService.h"
#include "host/PluginHostService.h"

void AudioService::start()
{
    // Host initializes audio on-demand (e.g. first playback). Keeping start() as a hook.
}

void AudioService::stop()
{
    // Ensure realtime audio is shut down if it was started.
    host_.shutdownAudio();
}
