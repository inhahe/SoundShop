#pragma once
#include "Common.h"


class SampleParamScheduler
{
public:
    void setHost(PluginHostService* h) { host = h; }

    void reset(int64_t startSample = 0)
    {
        timelineSample = startSample;
        nextIndex = 0;
        // Optionally prune old events if you reuse the vector across songs.
    }

    int64_t getTimelineSample() const noexcept { return timelineSample; }

    // Optional: if you want “block-level only” efficiency/stability,
    // choose a fixed quantum (e.g. 64 samples). Set to 1 for full sample accuracy.
    void setAutomationQuantum(int q) noexcept { automationQuantum = (q <= 0 ? 1 : q); }

    // Schedule at absolute sample time.
    void scheduleAtSample(int key, int paramIndex, float value, int64_t atSample)
    {
        if (automationQuantum > 1)
            atSample = (atSample / automationQuantum) * automationQuantum;

        ScheduledParameterChange e{ key, paramIndex, value, atSample };
        events.push_back(e);

        // Keep sorted. For minimal changes, sort whole vector.
        // If you care later: insert_sorted or sort only tail.
        std::sort(events.begin(), events.end(),
                  [](auto const& a, auto const& b) { return a.atSample < b.atSample; });

        // If you inserted an event before nextIndex, we must rewind conservatively.
        // Minimal safe approach:
        nextIndex = 0;
    }

    // Convenience: schedule relative to *current* timeline sample.
    void scheduleInSeconds(int key, int paramIndex, float value, double secondsFromNow, double sampleRate)
    {
        int64_t at = timelineSample + (int64_t) std::llround(secondsFromNow * sampleRate);
        scheduleAtSample(key, paramIndex, value, at);
    }

    // Process events in [blockStart, blockEnd).
    // Call BEFORE rendering audio for this block if you want changes to affect this block.
    void processBlock(int numSamples)
    {
        if (!host) return;

        const int64_t blockStart = timelineSample;
        const int64_t blockEnd   = blockStart + numSamples;

        // Skip past events strictly before this block.
        while (nextIndex < (int)events.size() && events[nextIndex].atSample < blockStart)
            ++nextIndex;

        // Apply all events that fall inside this block window (block-quantized).
        int i = nextIndex;
        while (i < (int)events.size() && events[i].atSample < blockEnd)
        {
            auto& e = events[i];
            host->setPluginParameter(e.key, e.parameterIndex, e.value);
            ++i;
        }
        nextIndex = i;

        // advance timeline for next callback / offline block
        timelineSample = blockEnd;
    }

    // Advance timeline by the *actual* numSamples each block/callback.
    void advance(int numSamples) noexcept
    {
        timelineSample += numSamples;
    }

    void clear()
    {
        events.clear();
        nextIndex = 0;
    }

private:
    PluginHostService* host = nullptr;

    std::vector<ScheduledParameterChange> events;
    int nextIndex = 0;

    std::atomic<int64_t> timelineSample = 0;

    int automationQuantum = 64; // choose 64/128 if you want “block-ish”; set 1 for sample-accurate scheduling
};

class ParamScheduler {
public:
  void setHost(PluginHostService* h) { host = h; }

  void reset(int64_t startSample = 0) {
    timelineSample = startSample;
    nextIndex = 0;
  }

  void scheduleAtSample(int key, int paramIndex, float value, int64_t atSample)
  {
    events.push_back({ key, paramIndex, value, atSample });
    // sort only here (command thread), never in audio thread
    std::sort(events.begin(), events.end(),
              [](auto& a, auto& b){ return a.atSample < b.atSample; });
  }

  // your processBlock() from earlier, with timelineSample advance
  void processBlock(int numSamples)
  {
    if (!host) return;

    const int64_t blockStart = timelineSample;
    const int64_t blockEnd   = blockStart + numSamples;

    while (nextIndex < (int)events.size() && events[nextIndex].atSample < blockStart)
      ++nextIndex;

    int i = nextIndex;
    while (i < (int)events.size() && events[i].atSample < blockEnd)
    {
      auto& e = events[i];
      host->setPluginParameter(e.key, e.parameterIndex, e.value);
      ++i;
    }
    nextIndex = i;

    timelineSample = blockEnd; // IMPORTANT
  }

  void clear() { events.clear(); nextIndex = 0; }

private:
  PluginHostService* host = nullptr;
  std::vector<ParameterChangeEvent> events;
  int nextIndex = 0;
  int64_t timelineSample = 0;
};

class LockFreeParameterQueue
{
private:
  static constexpr size_t QUEUE_SIZE = 1000000;
  std::array<ParameterChangeEvent, QUEUE_SIZE> queue;
  std::atomic<size_t> writeIndex{0};
  std::atomic<size_t> readIndex{0};

public:
  // Called from audio thread (fast, lock-free)
  bool push(const ParameterChangeEvent& event)
  {
    size_t currentWrite = writeIndex.load();
    size_t nextWrite = (currentWrite + 1) % QUEUE_SIZE;

    if (nextWrite == readIndex.load())
    {
      return false; // Queue full
    }

    queue[currentWrite] = event;
    writeIndex.store(nextWrite);
    return true;
  }

  // Called from main thread
  bool pop(ParameterChangeEvent& event)
  {
    size_t currentRead = readIndex.load();
    if (currentRead == writeIndex.load())
    {
      return false; // Queue empty
    }
    event = queue[currentRead];
    readIndex.store((currentRead + 1) % QUEUE_SIZE);
    return true;
  }
};

class LockFreeMidiQueue
{
private:
  static constexpr size_t QUEUE_SIZE = 100000;
  std::array<T, QUEUE_SIZE> queue;
  std::atomic<size_t> writeIndex{0};
  std::atomic<size_t> readIndex{0};

public:
  // Called from audio thread (fast, lock-free)
  bool push(const T& event)
  {
    size_t currentWrite = writeIndex.load();
    size_t nextWrite = (currentWrite + 1) % QUEUE_SIZE;

    if (nextWrite == readIndex.load())
    {
      return false; // Queue full
    }

    queue[currentWrite] = event;
    writeIndex.store(nextWrite);
    return true;
  }

  // Called from main thread
  bool pop(T& event)
  {
    size_t currentRead = readIndex.load();
    if (currentRead == writeIndex.load())
    {
      return false; // Queue empty
    }
    event = queue[currentRead];
    readIndex.store((currentRead + 1) % QUEUE_SIZE);
    return true;
  }
};
