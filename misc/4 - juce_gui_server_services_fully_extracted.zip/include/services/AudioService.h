#pragma once
#include "Common.h"
#include "ServerState.h"

class PluginHostService;

// Audio service boundary. In this pass, the host still owns the JUCE graph setup,
// but AudioService owns the lifecycle hooks (start/stop) so the wiring is centralized.
class AudioService
{
public:
    AudioService(ServerState& state, PluginHostService& host)
        : state_(state), host_(host) {}

    void start();
    void stop();

private:
    ServerState& state_;
    PluginHostService& host_;
};
