This folder contains a refactor of `juce_gui_server.cpp` into multiple smaller files grouped by purpose.

IMPORTANT:
- The code is still compiled as *one translation unit* by compiling `juce_gui_server.cpp`.
  That file includes the `*.inc` parts in the original order, so you avoid link/header dependency issues.

Files:
- JuceIncludes.h                 : all includes and platform headers
- protocol.inc                   : globals, enums, forward decls
- midi_scheduler.inc             : MidiScheduler
- audio_nodes.inc                : MidiSourceNode, AudioFilePlayerNode
- schedulers_and_listeners.inc   : param schedulers, lockfree queues, listeners, audio callback
- complete_plugin_host.inc       : CompletePluginHost + hosting/IPC logic
- main.inc                       : WinMain / main() entrypoints
