// This file was split from the original monolithic juce_gui_server.cpp into smaller units.
// Keep compiling THIS file; it includes the split parts in-order as a single translation unit.
//
// Original file: juce_gui_server.cpp

#include "JuceIncludes.h"

// The remainder is included in logical chunks:
#include "protocol.inc"
#include "midi_scheduler.inc"
#include "audio_nodes.inc"
#include "schedulers_and_listeners.inc"
#include "complete_plugin_host.inc"
#include "main.inc"
