#include "CompletePluginHost.h"
#include "ServerState.h"

#ifdef _WIN32

extern "C" int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    try
    {
        (void)hInstance;
        (void)hPrevInstance;
        (void)nCmdShow;

        // Allocate a console window for this GUI application
        AllocConsole();

        // Redirect stdout, stdin, stderr to console
        FILE* p = nullptr;
        freopen_s(&p, "CONOUT$", "w", stdout);
        freopen_s(&p, "CONOUT$", "w", stderr);
        freopen_s(&p, "CONIN$",  "r", stdin);

        // Optional: log stdout to a file
        // freopen_s(&p, "debug_log.txt", "w", stdout);

        std::cerr.clear();
        std::cin.clear();

        juce::initialiseJuce_GUI();

        ServerState state;
        if (lpCmdLine && !isAllWhitespace(lpCmdLine))
            state.config.pipeName = std::string(lpCmdLine);

        CompletePluginHost host(state);

        host.initialise(juce::String(lpCmdLine ? lpCmdLine : ""));
        juce::MessageManager::getInstance()->runDispatchLoop();
        host.shutdown();

        juce::shutdownJuce_GUI();
        return 0;
    }
    catch (const std::exception& e)
    {
        std::cerr << "Fatal error: " << e.what() << std::endl;
        return 1;
    }
}

#else

int main(int argc, char* argv[])
{
    juce::initialiseJuce_GUI();

    juce::String commandLine;
    for (int i = 1; i < argc; ++i)
    {
        if (i > 1) commandLine << " ";
        commandLine << argv[i];
    }

    ServerState state;
    if (commandLine.isNotEmpty())
        state.config.pipeName = commandLine.toStdString();

    CompletePluginHost host(state);
    host.initialise(commandLine);

    juce::MessageManager::getInstance()->runDispatchLoop();

    host.shutdown();
    juce::shutdownJuce_GUI();
    return 0;
}

#endif
