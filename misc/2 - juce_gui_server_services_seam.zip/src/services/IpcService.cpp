#include "services/IpcService.h"
#include "CompletePluginHost.h"

IpcService::IpcService(ServerState& state, CompletePluginHost& host)
    : state_(state), host_(host) {}

void IpcService::start()
{
    // TODO: move pipe creation + command/notification threads out of CompletePluginHost
    // host_.startIpc();  // (future)
}

void IpcService::stop()
{
    // TODO: host_.stopIpc(); (future)
}
