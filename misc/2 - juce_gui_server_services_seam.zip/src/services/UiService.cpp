#include "services/UiService.h"
#include "CompletePluginHost.h"

UiService::UiService(ServerState& state, CompletePluginHost& host)
    : state_(state), host_(host) {}

void UiService::showVirtualKeyboard()
{
    // TODO: route to host/UI classes
    // host_.showVirtualKeyboard();
}

void UiService::hideVirtualKeyboard()
{
    // host_.hideVirtualKeyboard();
}
