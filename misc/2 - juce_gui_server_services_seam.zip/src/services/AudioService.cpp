#include "services/AudioService.h"
#include "CompletePluginHost.h"

AudioService::AudioService(ServerState& state, CompletePluginHost& host)
    : state_(state)
    , host_(host)
    , callback_(host_, state_)
{
}

void AudioService::start()
{
    // TODO: move device manager init/start here from CompletePluginHost
}

void AudioService::stop()
{
    // TODO
}
