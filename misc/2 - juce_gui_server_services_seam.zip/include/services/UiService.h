#pragma once
#include "Common.h"
#include "ServerState.h"
class CompletePluginHost;

// UI service boundary (virtual keyboard window / editor windows / routing buttons).
class UiService
{
public:
    UiService(ServerState& state, CompletePluginHost& host);
    void showVirtualKeyboard();
    void hideVirtualKeyboard();
private:
    ServerState& state_;
    CompletePluginHost& host_;
};
