#pragma once
#include "Common.h"
#include "ServerState.h"
class CompletePluginHost;

// IPC service boundary (named pipes / sockets / command loop).
// Current implementation still lives inside CompletePluginHost; this is the seam.
class IpcService
{
public:
    IpcService(ServerState& state, CompletePluginHost& host);
    void start();
    void stop();
private:
    ServerState& state_;
    CompletePluginHost& host_;
};
