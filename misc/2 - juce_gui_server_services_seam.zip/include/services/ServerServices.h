#pragma once
#include "Common.h"
#include "ServerState.h"
#include "CompletePluginHost.h"

// Thin composition root to reduce cross-file globals and make future service extraction easier.
// This is a first step towards a "State + Services" architecture.
class ServerServices
{
public:
    explicit ServerServices(ServerState stateInit);

    // Starts the JUCE message loop / hosting as appropriate for your platform.
    // This mirrors the old main.cpp behavior.
    int run(int argc, char** argv);

    ServerState& state() { return state_; }
    CompletePluginHost& host() { return host_; }

private:
    ServerState state_;
    CompletePluginHost host_;
};
