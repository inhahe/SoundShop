#pragma once
#include "Common.h"
#include "audio/Events.h"
#include "audio/Schedulers.h"

class CompletePluginHost;
struct ServerState;

class ParameterChangeListener : public juce::AudioProcessorListener
{
public:
    ParameterChangeListener() = default;

    void setContext(CompletePluginHost* host, ServerState* state)
    {
        hostApp = host;
        serverState = state;
    }

    void audioProcessorParameterChanged(juce::AudioProcessor* processor,
                                        int parameterIndex,
                                        float newValue) override;

private:
    CompletePluginHost* hostApp = nullptr;
    ServerState* serverState = nullptr;
};
